//
//  ShapeViewController.swift
//  Shapes
//
//  Created by Narayana Rao on 22/10/18.
//  Copyright © 2018 Narayana Rao. All rights reserved.
//

import UIKit

class ShapeViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    //allocate shapeview
    func addShape(selectedShapeIndex:Int) {
        self.view.layer.sublayers?.forEach { $0.sublayers = nil }
        
        var width:CGFloat!
        var height:CGFloat!
        if selectedShapeIndex == 3{
            width = 160.0
            height = 160.0
        }else{
            width = 240.0
            height = 160.0
        }
        let shapeView = ShapeView(frame: CGRect(x: self.view.frame.size.width/2 - width/2,
                                                y: self.view.frame.size.height/2 - height/2,
                                                width: width,
                                                height: height))
        shapeView.shapeIndex = selectedShapeIndex
        self.view.addSubview(shapeView)
    }
    
    //touchesbegan delegate method
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.layer.sublayers?.forEach { $0.sublayers = nil }
    }

}
