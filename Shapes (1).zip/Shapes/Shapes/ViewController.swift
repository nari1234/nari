//
//  ViewController.swift
//  Shapes
//
//  Created by Narayana Rao on 14/10/18.
//  Copyright © 2018 Narayana Rao. All rights reserved.
//

import UIKit

class ViewController: ShapeViewController, UIPopoverPresentationControllerDelegate, ShapesDelegate {
    @IBOutlet weak var barBtn: UIBarButtonItem!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //let edgePan = UIScreenEdgePanGestureRecognizer(target: self, action: #selector(screenEdgeSwiped))
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func popoverPresentationControllerDidDismissPopover(_ popoverPresentationController: UIPopoverPresentationController){
        //do som stuff from the popover
    }
    
    func adaptivePresentationStyle(for controller: UIPresentationController) -> UIModalPresentationStyle {
        return UIModalPresentationStyle.none
    }
    
    //selected shape Delegate
    func selectedShape(shapeId: Int) {
        self.dismiss(animated: true, completion: nil)
        self.addShape(selectedShapeIndex: shapeId)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        //segue for the popover configuration window
        if segue.identifier == "popover" {
            if let controller = segue.destination as? ShapesListViewController {
                controller.popoverPresentationController!.delegate = self
                controller.delegate = self
                controller.preferredContentSize = CGSize(width: 320, height: 186)
            }
        }
    }
   
}

