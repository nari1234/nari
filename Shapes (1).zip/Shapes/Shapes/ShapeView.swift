//
//  ShapeView.swift
//  Shapes
//
//  Created by Narayana Rao on 14/10/18.
//  Copyright © 2018 Narayana Rao. All rights reserved.
//

import UIKit

class ShapeView: UIView {
    var path: UIBezierPath!
    
    var isResizingLR = false
    var isResizingUL = false
    var isResizingUR = false
    var isResizingLL = false
    
    var touchStart: CGPoint = CGPoint.zero
    var shapeIndex:Int!
    
    let kResizeThumbSize: CGFloat = 44
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        self.backgroundColor = UIColor.clear
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    func randomColor() -> UIColor {
        let hue:CGFloat = CGFloat(Float(arc4random()) / Float(UINT32_MAX))
        return UIColor(hue: hue, saturation: 1.0, brightness: 1.0, alpha: 1.0)
    }
    
    override func draw(_ rect: CGRect) {
        // Drawing code
        self.getSelectedShape()
        self.randomColor().setFill()
        path.fill()
        
        // Specify a border (stroke) color.
        self.randomColor().setStroke()
        path.stroke()
    }
 
    func getSelectedShape() {
        switch self.shapeIndex {
        case 0:
            print("Ellipse")
            self.path = UIBezierPath(ovalIn: self.bounds)
        case 1:
            print("Rectangle")
            self.createRectangle()
        case 2:
            print("Triangle")
            self.createTriangle()
        case 3:
            print("Star")
            self.createStar()
        default:
            break
        }
    }
    
    //method for Rectangle Shape
    func createRectangle() {
        // Initialize the path.
        path = UIBezierPath()
        path.move(to: CGPoint(x: 0.0, y: 0.0))
        path.addLine(to: CGPoint(x: 0.0, y: self.frame.size.height))
        path.addLine(to: CGPoint(x: self.frame.size.width, y: self.frame.size.height))
        path.addLine(to: CGPoint(x: self.frame.size.width, y: 0.0))
        path.close()
    }
    
    //method for Triangle Shape
    func createTriangle() {
        path = UIBezierPath()
        path.move(to: CGPoint(x: self.frame.width/2, y: 0.0))
        path.addLine(to: CGPoint(x: 0.0, y: self.frame.size.height))
        path.addLine(to: CGPoint(x: self.frame.size.width, y: self.frame.size.height))
        path.close()
    }
    
    //method for Star Shape
    func createStar() {
        path = UIBezierPath()
        
        let starExtrusion:CGFloat =  30.0
        
        let center = CGPoint(x: self.frame.width/2.0, y: self.frame.size.height / 2.0)
        
        let pointsOnStar = 5
        
        var angle:CGFloat = -CGFloat(Double.pi / 2.0)
        let angleIncrement = CGFloat(Double.pi * 2.0 / Double(pointsOnStar))
        let radius = self.frame.size.width / 2.0
        
        var firstPoint = true
        
        for _ in 1...pointsOnStar {
            let point = self.pointFrom(angle: angle, radius: radius, offset: center)
            let nextPoint = self.pointFrom(angle: angle + angleIncrement, radius: radius, offset: center)
            let midPoint = self.pointFrom(angle: angle + angleIncrement / 2.0, radius: starExtrusion, offset: center)
            
            if firstPoint {
                firstPoint = false
                path.move(to: point)
            }
            
            path.addLine(to: midPoint)
            path.addLine(to: nextPoint)
            
            angle += angleIncrement
        }
        path.close()
    }
    
    func pointFrom(angle: CGFloat, radius: CGFloat, offset: CGPoint) -> CGPoint {
        return CGPoint(x: radius * cos(angle) + offset.x, y: radius * sin(angle) + offset.y)
    }

    func crossLine(start p0: CGPoint, end p1: CGPoint, view: UIView) {
        let shapeLayer = CAShapeLayer()
        shapeLayer.strokeColor = UIColor.darkGray.cgColor
        shapeLayer.lineWidth = 3
        shapeLayer.lineDashPattern = [5, 4]
        
        let path = CGMutablePath()
        path.addLines(between: [p0, p1])
        shapeLayer.path = path
        view.layer.addSublayer(shapeLayer)
    }
    
    func addDottedBorder() {
        self.layer.sublayers = nil
        let border = CAShapeLayer();
        border.strokeColor = UIColor.darkGray.cgColor;
        border.lineWidth = 3
        border.fillColor = nil;
        border.lineDashPattern = [5, 4];
        border.path = UIBezierPath(rect: self.bounds).cgPath
        border.frame = self.bounds;
        self.layer.addSublayer(border);
        
        self.superview?.bringSubview(toFront: self)
    }
    
    //touches Delegate functions
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.superview?.layer.sublayers?.forEach { $0.sublayers = nil }
        self.addDottedBorder()
        self.crossLine(start: CGPoint(x: self.bounds.maxX, y: self.bounds.maxY - 20), end: CGPoint(x: self.bounds.maxX - 20, y: self.bounds.maxY), view: self)
        
        self.touchStart = touches.first!.location(in: self)
        self.isResizingLR = (self.bounds.size.width - touchStart.x < kResizeThumbSize && self.bounds.size.height - touchStart.y < kResizeThumbSize)
        //self.isResizingUL = (touchStart.x < kResizeThumbSize && touchStart.y < kResizeThumbSize)
        //self.isResizingUR = (self.bounds.size.width-touchStart.x < kResizeThumbSize && touchStart.y < kResizeThumbSize)
        //self.isResizingLL = (touchStart.x < kResizeThumbSize && self.bounds.size.height - touchStart.y < kResizeThumbSize)
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.superview?.layer.sublayers?.forEach { $0.sublayers = nil }
        
        let touchPoint = touches.first!.location(in: self)
        let previous = touches.first!.previousLocation(in: self)
        
        let deltaWidth =  previous.x - touchPoint.x
        let deltaHeight = previous.y - touchPoint.y
        
        let x = self.frame.origin.x;
        let y = self.frame.origin.y;
        let width = self.frame.size.width;
        let height = self.frame.size.height;
        
        let originFrame = self.frame
        var finalFrame: CGRect = originFrame
        
        if (isResizingLR) {
            
            let distance = CGPoint(x: 1.0 - (deltaWidth / width),
                                   y: 1.0 - (deltaHeight / height))
            
            let scale = (distance.x + distance.y) * 0.5
            
            finalFrame.size.width = width * scale
            finalFrame.size.height = height * scale
            
            self.addDottedBorder()
            self.crossLine(start: CGPoint(x: self.bounds.maxX, y: self.bounds.maxY - 20), end: CGPoint(x: self.bounds.maxX - 20, y: self.bounds.maxY), view: self)
            
        } else if (isResizingUL) {
            let distance = CGPoint(x: 1.0 - (-deltaWidth / width),
                                   y: 1.0 - (-deltaHeight / height))
            
            let scale = (distance.x + distance.y) * 0.5
            
            finalFrame.size.width = width * scale
            finalFrame.size.height = height * scale
            finalFrame.origin.x = x + width - finalFrame.size.width;
            finalFrame.origin.y = y + height - finalFrame.size.height;
        } else if (isResizingUR) {
            let distance = CGPoint(x: 1.0 - (deltaWidth / width),
                                   y: 1.0 - (-deltaHeight / height))
            
            let scale = (distance.x + distance.y) * 0.5
            
            finalFrame.size.width = width * scale
            finalFrame.size.height = height * scale
            finalFrame.origin.y = y + height - finalFrame.size.height
        } else if (isResizingLL) {
            let distance = CGPoint(x: 1.0 - (-deltaWidth / width),
                                   y: 1.0 - (deltaHeight / height))
            
            let scale = (distance.x + distance.y) * 0.5
            
            finalFrame.size.width = width * scale
            finalFrame.size.height = height * scale
            finalFrame.origin.x = originFrame.maxX - finalFrame.size.width
        } else {
            // not dragging from a corner -- move the view
            let newCenter = CGPoint(x: self.center.x + touchPoint.x - touchStart.x,
                                    y: self.center.y + touchPoint.y - touchStart.y)
            
            if (newCenter.x + self.bounds.midX <= self.superview!.bounds.maxX && newCenter.x - self.bounds.midX >= self.superview!.bounds.minX && newCenter.y + self.bounds.midY <= self.superview!.bounds.maxY && newCenter.y - self.bounds.midY >= self.superview!.bounds.minY)
            {
                self.center = newCenter
            }
            self.addDottedBorder()
            self.crossLine(start: CGPoint(x: self.bounds.maxX, y: self.bounds.maxY - 20), end: CGPoint(x: self.bounds.maxX - 20, y: self.bounds.maxY), view: self)
            return;
        }
        
        if (finalFrame.maxX <= self.superview!.bounds.maxX && finalFrame.minX >= self.superview!.bounds.minX && finalFrame.maxY <= self.superview!.bounds.maxY && finalFrame.minY >= self.superview!.bounds.minY) {
            self.frame = finalFrame
        }
    }
    
}

